#include "biblioteca.h"
#include "genero.h"
#include <iostream>

int main (){
    Livro l;
    std::cout << l.generoStr()<<'\n';
}
