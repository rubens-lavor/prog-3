#ifndef BIBLIOTECA_H
#define BIBLIOTECA_H

#include "genero.h"

class Biblioteca{
    Livro umlivro;
};

#endif